export const newsData = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&h=300&fit=crop",
    headline: "Market opens strong as NIFTY hits new weekly highs.",
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=500&h=300&fit=crop",
    headline: "Tech stocks rally after positive Q3 earnings reports.",
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=500&h=300&fit=crop",
    headline: "Global markets stabilize amid easing inflation fears.",
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&h=300&fit=crop",
    headline: "Investors shift focus toward energy sector growth.",
  },
  {
    id: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=300&fit=crop",
    headline: "Stock market sees record trading volume this week.",
  }
];